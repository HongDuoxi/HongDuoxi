import java.util.ArrayList;

public class DtoTest_1 {
	//ArrayList<> list = new ArrayList<>(); /*1 <꺽새>안에 StudentDto 안적고 아무것도 안적으면 Object타입으로 자동 설정됨 *2를 찾아
	ArrayList<StudentDto> list = new ArrayList<>();
	
	public void aa() {
		String persons[] = new String[3];
		persons[0] = "홍다희";
		persons[1] = "이슬기";
		persons[2] = "박정은";
		for(String s:persons){
			System.out.println(s);
		}	
	}

	public void insertData() { //여러명의 학생 정보를 기억
		
		StudentDto dto = null;
	
		dto = new StudentDto();
		dto.setHakbun("b293099");
		dto.setIrum("슬기");
		dto.setJumsu(88);
		list.add(dto); //고무줄처럼 아래로 행이 늘어나는 Arraylist(컬렉션)에 담아두자. 순서가 있음. 0번째로 들어감
		
		dto = new StudentDto();
		dto.setHakbun("b093100");
		dto.setIrum("다희");
		dto.setJumsu(99);
		list.add(dto);
		
		dto = new StudentDto();
		dto.setHakbun("b193100");
		dto.setIrum("민승");
		dto.setJumsu(85);
		list.add(dto);
		
		dto = new StudentDto();
		dto.setHakbun("b293100");
		dto.setIrum("백용");
		dto.setJumsu(95);
		list.add(dto);
		
		System.out.println(dto);
		
	}
	
	public void displayData() {
		System.out.println("\n저장된 학생 수: " + list.size() + "명");
		System.out.println();
		for(int k = 0; k < list.size(); k++) {
			StudentDto dto = list.get(k); //프린트하는 방법. 꺼내주는 방법.
			//StudentDto dto = (StudentDto)list.get(k); //*2 그럼 여기서 캐스팅을 해줘야 됨.
			System.out.println(dto.getHakbun() + " " + dto.getIrum() + " " + dto.getJumsu());
		}
	}
	
	public static void main(String[] args) {
		
		DtoTest_1 test1 = new DtoTest_1();
		test1.aa();
		test1.insertData();
		test1.displayData();
	}

}
