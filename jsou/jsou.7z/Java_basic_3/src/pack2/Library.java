package pack2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.StringTokenizer;

public class Library {

	public static void main(String[] args) throws Exception {

		File file = new File("c:\\work\\전국도서관표준데이터.csv");
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);

		while (true) {
			String ss = br.readLine();

			if (ss == null) {
				break;
			}

			StringTokenizer tok = new StringTokenizer(ss, ",");

			String name1 = tok.nextToken(); // 시설종류
			String name2 = tok.nextToken(); // 대상시설명
			String name3 = tok.nextToken(); // 소재지도로명주소
			String name4 = tok.nextToken();

			System.out.println("도서관명:" + "\t" + name1);
			System.out.println("소재지명:" + "\t" + name2 + " " + name3);
			System.out.println("도서관류:  " + name4);
			System.out.println("-----------------------");
			//System.out.println(ss);
		}
		br.close();
		fr.close();

	}

}
