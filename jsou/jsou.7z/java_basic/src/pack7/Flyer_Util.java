package pack7;

public class Flyer_Util {
	
	public static void showData(Flyer f) {
		f.fly();
		System.out.println("동물인가요? " + f.isAnimal());
	}

}
