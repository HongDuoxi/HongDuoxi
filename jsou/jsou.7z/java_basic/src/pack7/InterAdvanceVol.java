package pack7;

//public interface InterAdvanceVol {
public interface InterAdvanceVol extends InterVol{ //인터페이스끼리 상속이 가능
	
	void volOff();
	void volResume();

}
