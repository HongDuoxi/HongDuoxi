package pack7;

public interface Flyer {
	
	int FAST = 100; //final static
	
	void fly();
	boolean isAnimal();

}
