package pack7;

public interface InterVol {
	
	String VOL = "볼륨";
	
	void volUp(int v);
	void volDown(int v);

}
