package pack8;

public class Saram {

	private String irum = "홍다희";
	
	public String getIrum() {
		return irum;
	}

}
