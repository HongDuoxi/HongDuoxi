package pack3;

public class StuTom_4 extends Student_4{
	
	public StuTom_4() {
		System.out.println("StuTom_4 생성자");
	}
	
	

}
