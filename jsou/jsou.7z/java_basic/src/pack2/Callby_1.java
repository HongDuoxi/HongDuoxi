package pack2;

public class Callby_1 {
	
	int a = 10, b = 20; //기본형 멤버필드, 멤버변수
	int c[] = {1, 2}; //참조형 멤버필드
	
}
