package pack6;

public interface Volunm {
	//일반 메소드 못 들어옴
	//앞에 abstract public 기 셍략되어 있다.
	//상속이 아닌 구현이라고 말한다.
	void volunmUp(int level);
	void volunmDown(int level);
	
/*	public void aa() {
		//일반 메소드 기술 불가
	}*/
	//인터페이스도 클래스. 객체를 만들 수 없으나 객체변수 선언은 가능
	//인터페이스랑 상속의 차이를 잘 모르겠어..ㅠ.ㅠ
	
	
}
