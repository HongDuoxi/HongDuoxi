package samples;

public class Practice_MachineUse {

	public static void main(String[] args) {
		
		Practice_Machine aa = new Practice_Machine();
		aa.showDate();

	}

}
