package samples;

public class MachineUse {

	public static void main(String[] args) {
		
		Machine aa = new Machine();
		aa.showData();
		
	}

}
