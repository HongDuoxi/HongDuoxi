package pack5;

abstract public class Ani_Dog extends Animal{
	
	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "멍멍이";
	}
	
	//부모 클래스의 추상 메소드를 모두 오버라이딩 하지 않은 경우 
	//얘도 추상 클래스가 된다!
	
}
