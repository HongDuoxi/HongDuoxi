package pack5;

public class Ani_Cow extends Animal{
	
	@Override
	public String name() {
		return "소";
	}
	
	@Override
	public String eat() {
		return "초식성";
	}
	
	@Override
	public String action() {
		return "음메음메~";
	}

}
