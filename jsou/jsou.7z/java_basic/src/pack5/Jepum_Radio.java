package pack5;

public class Jepum_Radio extends Jepum{

	@Override
	public void volunmControl() {
		System.out.println("Radio 소리조절");
	}
}
