package pack4;

public class PolyRadio extends PolyProduct{
	
	@Override
	public void volumnControl() {
		System.out.println("라디오 소리 조절 후: " + getVolumn());
	}
	
	

}
