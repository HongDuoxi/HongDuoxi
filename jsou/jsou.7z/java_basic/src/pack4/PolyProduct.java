package pack4;

public class PolyProduct { //가전제품 원형 클래스(super, 부모 클래스)
	
	private int volumn = 0;
	
	public void volumnControl() {
		//내용은 비워둠 - 오버라이딩된 메소드에서 구체적인 내용 적어줌
	}
	
	public void setVolumn(int volumn) {
		this.volumn = volumn;
	}
	
	public int getVolumn() {
		return volumn;
	}
	

}
